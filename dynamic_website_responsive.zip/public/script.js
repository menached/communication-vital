
const contentData = {
    mission: "<h2>Our Mission</h2><p>Our mission is to create a path towards a fulfilling life for individuals with autistic language deficiencies and other communication challenges. We believe that every person deserves to communicate effectively and live safely within a supportive environment. Through community engagement, safety-first policies, and a dedication to development, we aim to help these individuals reach their highest potential.</p>",
    about: "<h2>About Us</h2><p>We are a dedicated organization committed to fostering an inclusive and supportive community. Our core principles revolve around creating opportunities for all, overcoming obstacles, and prioritizing safety. By connecting non-verbal adults and developmentally disabled individuals with peers and supportive networks, we are building a certified autism-friendly community. This initiative allows participants to live, visit, or interact with others who share similar experiences and challenges.</p><p>Our approach is holistic and family-oriented, understanding that each person’s needs are unique. We strive to address the growing challenges faced by autistic adults and their families, offering them a chance to belong to a community where acceptance, understanding, and personal development are paramount.</p>",
    contact: "<h2>Contact Us</h2><p>We'd love to hear from you! For more information about our programs, partnerships, or to get involved, please reach out to us at:</p><p><strong>Jon Fleischer</strong><br>Email: <a href='mailto:jdfly19@yahoo.com'>jdfly19@yahoo.com</a><br>Phone: <a href='tel:+16617433143'>‪(661) 743-3143‬</a></p>"
};

function showSection(section) {
    document.getElementById('content').innerHTML = contentData[section];
}

window.addEventListener('scroll', function() {
    const sections = document.querySelectorAll('.reveal');
    sections.forEach(section => {
        const sectionTop = section.getBoundingClientRect().top;
        if (sectionTop < window.innerHeight) {
            section.classList.add('visible');
        } else {
            section.classList.remove('visible');
        }
    });
});

const teamData = [
    { name: "John Doe", role: "Founder", bio: "Passionate about making a difference..." },
    { name: "Jane Smith", role: "Director", bio: "Focused on fostering communication..." }
];

function loadTeam() {
    const teamSection = document.getElementById('team');
    teamData.forEach(member => {
        const memberDiv = document.createElement('div');
        memberDiv.innerHTML = `<h3>${member.name}</h3><p>${member.role}</p><p>${member.bio}</p>`;
        teamSection.appendChild(memberDiv);
    });
}

window.onload = loadTeam;

function toggleModal() {
    document.getElementById('modal').classList.toggle('hidden');
}

function submitForm() {
    const email = document.getElementById('email').value;
    if (email) {
        alert(`Thank you for subscribing, ${email}!`);
        toggleModal();
    } else {
        alert('Please enter a valid email.');
    }
}
